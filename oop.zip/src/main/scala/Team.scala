package oop
class Team (offense: Int, deffense: Int) {
	
	val strength_defense : Int = deffense
	val strength_offense : Int = offense
	var score: Int = 0	

}